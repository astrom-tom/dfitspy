*See [here](https://astrom-tom.github.io/dfitspy/build/html/index.html) to display the documentation.*



