__version__ = '20.4.1'
__place__ = 'ESO Paranal observatory'
__credits__ = "Romain Thomas"
__license__ = "GNU GPL v3"
__maintainer__ = "Romain Thomas"
__email__ = "the.spartan.proj@gmail.com"
__status__ = "released"
__website__ = "https://astrom-tom.github.io/dfitspy/build/html/index.html"
