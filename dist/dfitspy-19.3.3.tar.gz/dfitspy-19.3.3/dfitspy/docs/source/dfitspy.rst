get files and keys functions
----------------------------

.. automodule:: dfitspy.get_files_and_keys
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: Testgetfiles, Testgetkeys

readfits functions
------------------

.. automodule:: dfitspy.readfits
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: read_fitsfile, Testextractheader, Testkeywordextraction, keywords_in_file

display function 
----------------

.. automodule:: dfitspy.display
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: Testdisplaylist, Testdisplayfinal


tests module
------------

.. automodule:: dfitspy.tests
    :members:
    :undoc-members:
    :show-inheritance:

